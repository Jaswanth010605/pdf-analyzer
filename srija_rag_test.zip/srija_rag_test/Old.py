# streamlit_app.py

import streamlit as st
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import faiss
import google.generativeai as genai
from docling.document_converter import DocumentConverter
import fitz  # PyMuPDF
import pandas as pd
import io
from PIL import Image
from pathlib import Path
import warnings

# Suppress pin_memory warnings
warnings.filterwarnings("ignore", message=".*pin_memory.*")

# Configure API Key
genai.configure(api_key="AIzaSyCXRe5_WgpdYJihAVrNte8phT2DW7m650U")  # Replace with your actual API key

# Load Embedding Model
embedder = SentenceTransformer('all-MiniLM-L6-v2')

# Global variables
faiss_index = None
text_chunks = []
debug_mode = False  # Global debug flag

# Deduplicate Column Names
def deduplicate_columns(columns):
    counts = {}
    new_columns = []
    for col in columns:
        if col in counts:
            counts[col] += 1
            new_columns.append(f"{col}.{counts[col]}")
        else:
            counts[col] = 0
            new_columns.append(col)
    return new_columns

# Data Cleaning Function with Debug
def clean_dataframe(df):
    """
    Cleans a pandas dataframe by:
    1. Converting all column names to strings
    2. Stripping extra spaces from column names
    3. Replacing empty names
    4. Deduplicating names
    """

    original_columns = list(df.columns)

    # Step 1: Convert all column names to strings
    df.columns = df.columns.map(str)

    # Step 2: Strip leading/trailing spaces
    df.columns = df.columns.str.strip()

    # Step 3: Replace empty column names with 'Unnamed'
    df.columns = [col if col != '' else 'Unnamed' for col in df.columns]

    # Step 4: Deduplicate column names safely
    df.columns = deduplicate_columns(df.columns)

    cleaned_columns = list(df.columns)

    # Debug Logging
    if debug_mode:
        st.write(f"**Original Columns:** {original_columns}")
        st.write(f"**Cleaned Columns:** {cleaned_columns}")

    return df

# Chunking Function
def chunk_text(text, chunk_size=500, chunk_overlap=50):
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return splitter.split_text(text)

# Create FAISS Vector Store
def create_vector_store(chunks):
    global faiss_index
    embeddings = embedder.encode(chunks)
    dimension = embeddings.shape[1]
    faiss_index = faiss.IndexFlatL2(dimension)
    faiss_index.add(embeddings)
    return chunks

# Retrieve Relevant Chunks
def retrieve_context(query, k=3):
    query_embedding = embedder.encode([query])
    distances, indices = faiss_index.search(query_embedding, k)
    return [text_chunks[i] for i in indices[0]]

# Extract Tables from PDF
def extract_tables(pdf_path: Path):
    tables = []
    doc_converter = DocumentConverter()
    conv_res = doc_converter.convert(pdf_path)

    for table_ix, table in enumerate(conv_res.document.tables):
        table_df = table.export_to_dataframe()

        # Clean the dataframe to remove duplicates and extra spaces
        cleaned_df = clean_dataframe(table_df)

        tables.append({
            'index': table_ix + 1,
            'dataframe': cleaned_df,
            'description': generate_table_description(cleaned_df)
        })
    return tables

# Describe Table using Gemini API
def generate_table_description(table_df):
    table_markdown = table_df.to_markdown(index=False)
    model = genai.GenerativeModel('gemini-1.5-flash-latest')

    prompt = f"""
    Summarize the following table in a simple, clear, and reader-friendly way.
    - Explain the table's purpose.
    - Highlight key trends, maximum/minimum values, and comparisons.
    - Use a short paragraph.

    Table:
    {table_markdown}
    """

    try:
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception:
        return "Error generating description."

# Extract Images from PDF
def extract_images(pdf_bytes, pdf_name):
    images = []
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")

    for page_index in range(len(doc)):
        page = doc[page_index]
        imgs = page.get_images(full=True)

        for img_index, img in enumerate(imgs):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image = Image.open(io.BytesIO(image_bytes))
            images.append({'page': page_index + 1, 'image': image})

    doc.close()
    return images

# Build Streamlit App
def main():
    global debug_mode
    st.title("📄 PDF Question Answering using RAG with Gemini API")

    # Debug toggle
    debug_mode = st.sidebar.checkbox("Enable Debug Mode", value=False)

    uploaded_file = st.file_uploader("Upload your PDF", type=["pdf"])

    if uploaded_file is not None:
        with st.spinner('Processing PDF...'):
            pdf_path = Path(uploaded_file.name)
            with open(pdf_path, "wb") as f:
                f.write(uploaded_file.getbuffer())

            pdf_bytes = uploaded_file.read()

            # Extract Tables and Images
            tables = extract_tables(pdf_path)
            images = extract_images(pdf_bytes, pdf_path.stem)

            # Build Context
            full_text = ""
            for table in tables:
                full_text += table['dataframe'].to_string(index=False) + "\n" + table['description'] + "\n"
            for img in images:
                full_text += f"[Image on Page {img['page']}]\n"

            global text_chunks
            text_chunks = chunk_text(full_text)
            create_vector_store(text_chunks)

        st.success("PDF Processed Successfully!")

        # Display Tables
        st.subheader("Extracted Tables and Descriptions:")
        for table in tables:
            st.write(f"**Table {table['index']}**")
            st.dataframe(table['dataframe'])
            st.write(f"*Description:* {table['description']}")

        # Display Images
        if images:
            st.subheader("Extracted Images:")
            for img_data in images:
                st.image(img_data['image'], caption=f"Page {img_data['page']}", use_column_width=True)

        # Question Answering
        st.subheader("Ask Questions from PDF:")
        question = st.text_input("Enter your question here:")

        if st.button("Get Answer") and question:
            retrieved = retrieve_context(question)
            combined_context = " ".join(retrieved)

            qa_prompt = f"Use the following context to answer the question accurately and in detail.\n\nContext:\n{combined_context}\n\nQuestion: {question}\n\nAnswer:"
            model = genai.GenerativeModel('gemini-1.5-flash-latest')
            try:
                response = model.generate_content(qa_prompt)
                answer = response.text.strip()
            except Exception:
                answer = "Error generating answer."

            st.write(f"**Answer:** {answer}")

if __name__ == "__main__":
    main()